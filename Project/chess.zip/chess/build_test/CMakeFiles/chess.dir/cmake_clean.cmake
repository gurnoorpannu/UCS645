file(REMOVE_RECURSE
  "CMakeFiles/chess.dir/src/board.cpp.o"
  "CMakeFiles/chess.dir/src/board.cpp.o.d"
  "CMakeFiles/chess.dir/src/eval.cpp.o"
  "CMakeFiles/chess.dir/src/eval.cpp.o.d"
  "CMakeFiles/chess.dir/src/main.cpp.o"
  "CMakeFiles/chess.dir/src/main.cpp.o.d"
  "CMakeFiles/chess.dir/src/movegen.cpp.o"
  "CMakeFiles/chess.dir/src/movegen.cpp.o.d"
  "CMakeFiles/chess.dir/src/search_cuda.cpp.o"
  "CMakeFiles/chess.dir/src/search_cuda.cpp.o.d"
  "CMakeFiles/chess.dir/src/search_omp.cpp.o"
  "CMakeFiles/chess.dir/src/search_omp.cpp.o.d"
  "CMakeFiles/chess.dir/src/search_serial.cpp.o"
  "CMakeFiles/chess.dir/src/search_serial.cpp.o.d"
  "chess"
  "chess.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/chess.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
