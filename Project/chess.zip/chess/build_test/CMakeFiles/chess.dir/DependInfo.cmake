
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/gurnoor/Projects/chess/src/board.cpp" "CMakeFiles/chess.dir/src/board.cpp.o" "gcc" "CMakeFiles/chess.dir/src/board.cpp.o.d"
  "/Users/gurnoor/Projects/chess/src/eval.cpp" "CMakeFiles/chess.dir/src/eval.cpp.o" "gcc" "CMakeFiles/chess.dir/src/eval.cpp.o.d"
  "/Users/gurnoor/Projects/chess/src/main.cpp" "CMakeFiles/chess.dir/src/main.cpp.o" "gcc" "CMakeFiles/chess.dir/src/main.cpp.o.d"
  "/Users/gurnoor/Projects/chess/src/movegen.cpp" "CMakeFiles/chess.dir/src/movegen.cpp.o" "gcc" "CMakeFiles/chess.dir/src/movegen.cpp.o.d"
  "/Users/gurnoor/Projects/chess/src/search_cuda.cpp" "CMakeFiles/chess.dir/src/search_cuda.cpp.o" "gcc" "CMakeFiles/chess.dir/src/search_cuda.cpp.o.d"
  "/Users/gurnoor/Projects/chess/src/search_omp.cpp" "CMakeFiles/chess.dir/src/search_omp.cpp.o" "gcc" "CMakeFiles/chess.dir/src/search_omp.cpp.o.d"
  "/Users/gurnoor/Projects/chess/src/search_serial.cpp" "CMakeFiles/chess.dir/src/search_serial.cpp.o" "gcc" "CMakeFiles/chess.dir/src/search_serial.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
